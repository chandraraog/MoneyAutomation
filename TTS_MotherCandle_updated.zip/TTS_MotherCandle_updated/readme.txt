PS C:\dashboard\TTS_MotherCandle_updated\OIDataV2> 
python C:\dashboard\TTS_MotherCandle_updated\OIDataV2\server.py