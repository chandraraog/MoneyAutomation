'use strict';
const $=id=>document.getElementById(id);
let automationInitialized=false;
for(const id of ['hourlyScan','telegramAlerts'])$(id).onchange=()=>{automationInitialized=true;};
$('saveAutomation').onclick=async()=>{try{const r=await fetch('/api/macd/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({hourly:$('hourlyScan').checked,alerts:$('telegramAlerts').checked})});const data=await r.json();if(!r.ok)throw Error(data.error);$('automationStatus').textContent='Settings saved';}catch(e){$('automationStatus').textContent=e.message;}};
let report=null, busy=false, theme='dark', priceInitialized=false;
let oiHistory=[], oiSnapshots=[], oiCacheKey='', oiLoading=null, activeOiCell=null, oiHideTimer=null;
$('scanMinPrice').addEventListener('input',()=>{priceInitialized=true;});
try {theme=localStorage.getItem('market-desk-theme') || 'light';} catch {}
function applyTheme(){document.documentElement.dataset.theme=theme; $('theme').textContent=theme==='dark'?'White theme':'Black theme'; $('theme').setAttribute('aria-label','Switch to '+(theme==='dark'?'white':'black')+' theme');}
applyTheme();
try {const saved=localStorage.getItem('macd-universe');if(['watchlist','bhavcopy'].includes(saved))$('universe').value=saved;} catch {}
$('theme').onclick=()=>{theme=theme==='dark'?'light':'dark';applyTheme();try{localStorage.setItem('market-desk-theme',theme);}catch{}};
function fmtOi(v){return v==null?'—':typeof v==='number'?v.toLocaleString('en-IN',{maximumFractionDigits:2}):String(v);}
function oiLongShortView(row){const terms=[row?.Future,row?.['CE Term'],row?.['PE Term']];if(terms.some(value=>!value||String(value).trim()==='—'))return 'Incomplete';const [future,ce,pe]=terms.map(value=>String(value).toLowerCase());if(future==='long buildup'&&ce==='short covering'&&pe==='short buildup')return 'Long setup';if(future==='short buildup'&&ce==='short buildup'&&pe==='short covering')return 'Short setup';return 'Mixed / no match';}
async function loadOiSnapshots(){
 const ordered=[...oiHistory].sort((a,b)=>String(b.scope||b.stamp).localeCompare(String(a.scope||a.stamp))),days=new Set();
 const items=ordered.filter(item=>{const day=String(item.scope||item.stamp).slice(0,10);if(days.has(day))return false;days.add(day);return true;}).slice(0,3);
 const key=items.map(item=>item.id).join(',');if(key===oiCacheKey)return oiSnapshots;if(oiLoading)return oiLoading;
 oiLoading=Promise.all(items.map(item=>fetch(`/api/snapshot?job=nse&id=${encodeURIComponent(item.id)}`).then(async response=>{const data=await response.json();if(!response.ok)throw Error(data.error||'Snapshot unavailable');return data.snapshot;}))).then(data=>{oiSnapshots=data.filter(Boolean);oiCacheKey=key;return oiSnapshots;}).finally(()=>{oiLoading=null;});return oiLoading;
}
function paintOiTooltip(box,symbol,snapshots){
 box.replaceChildren();const title=document.createElement('div');title.className='oi-hover-title';const text=document.createElement('span');text.textContent=`${symbol} · last ${snapshots.length} days`;title.append(text);box.append(title);
 const latest=(snapshots[0]?.rows||[]).find(row=>String(row.Symbol||'').toUpperCase()===symbol),longShort=latest?oiLongShortView(latest):'Incomplete';const netLine=document.createElement('div');netLine.className='oi-hover-net';netLine.textContent=`Final View: ${longShort}`;box.append(netLine);
 const table=document.createElement('table'),head=document.createElement('tr');for(const label of ['Date','Future','CE','PE']){const th=document.createElement('th');th.textContent=label;head.append(th);}table.append(head);
 for(const saved of snapshots){const row=(saved.rows||[]).find(item=>String(item.Symbol||'').toUpperCase()===symbol),tr=document.createElement('tr'),raw=saved.trade_date||saved.collected_at,date=raw&&/^\d{4}-\d{2}-\d{2}$/.test(raw)?raw.split('-').reverse().join('/'):raw?new Date(raw).toLocaleDateString('en-IN',{timeZone:'Asia/Kolkata',month:'2-digit',day:'2-digit',year:'numeric'}):'—',dateCell=document.createElement('td');dateCell.textContent=date;tr.append(dateCell);for(const key of ['Fut OI Chg','CE OI Chg','PE OI Chg']){const td=document.createElement('td'),value=row?.[key];td.textContent=fmtOi(value);td.title='Daily change in open interest (contracts)';if(typeof value==='number')td.className=value>0?'oi-hover-up':value<0?'oi-hover-down':'oi-hover-flat';tr.append(td);}table.append(tr);}
 if(!snapshots.length){const empty=document.createElement('p');empty.textContent='No saved NSE snapshots found.';box.append(empty);return;}box.append(table);const actions=document.createElement('div');actions.className='oi-hover-actions';const copyImage=document.createElement('button');copyImage.type='button';copyImage.className='oi-hover-copy';copyImage.textContent='Copy as image';copyImage.onclick=async event=>{event.preventDefault();event.stopPropagation();try{const rows=[...table.rows].map(row=>[...row.cells]),scale=2,pad=16,width=620,rowH=38,titleH=34,netH=28,height=pad*2+titleH+netH+rows.length*rowH,canvas=document.createElement('canvas');canvas.width=width*scale;canvas.height=height*scale;const ctx=canvas.getContext('2d');ctx.scale(scale,scale);ctx.fillStyle='#fff';ctx.fillRect(0,0,width,height);ctx.fillStyle='#172433';ctx.font='600 17px Segoe UI,Arial';ctx.textBaseline='middle';ctx.fillText(`${symbol} · Open Interest (last ${Math.max(0,rows.length-1)} days)`,pad,pad+titleH/2);ctx.font='600 13px Segoe UI,Arial';ctx.fillText(`Final View: ${longShort}`,pad,pad+titleH+netH/2);const widths=[170,150,130,130],labels=['Date','Future','CE','PE'];let y=pad+titleH+netH;for(let ri=0;ri<rows.length;ri++){let x=pad;for(let ci=0;ci<4;ci++){const cell=rows[ri][ci],up=cell.classList.contains('oi-hover-up'),down=cell.classList.contains('oi-hover-down');ctx.fillStyle=ri===0?'#e8eef4':up?'#d8ead1':down?'#f8d7d4':'#fff';ctx.fillRect(x,y,widths[ci],rowH);ctx.strokeStyle='#cbd5e1';ctx.strokeRect(x,y,widths[ci],rowH);ctx.fillStyle=up?'#17632b':down?'#b42318':'#26384a';ctx.font=ri===0?'600 13px Segoe UI,Arial':'13px Segoe UI,Arial';ctx.textAlign=ci===0?'left':'right';ctx.fillText(ri===0?labels[ci]:cell.textContent.trim(),x+(ci===0?9:widths[ci]-9),y+rowH/2);x+=widths[ci];}y+=rowH;}const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));await navigator.clipboard.write([new ClipboardItem({'image/png':blob})]);copyImage.textContent='Image copied';setTimeout(()=>{if(copyImage.isConnected)copyImage.textContent='Copy as image';},1500);}catch{copyImage.textContent='Image copy unavailable';}};const copyText=document.createElement('button');copyText.type='button';copyText.className='oi-hover-copy';copyText.textContent='Copy text';copyText.onclick=async event=>{event.preventDefault();event.stopPropagation();const data=[...table.rows].map(row=>[...row.cells].map(cell=>cell.textContent.trim()));const text=`*${symbol} · Open Interest (last ${Math.max(0,data.length-1)} days)*\nFinal View: ${longShort}\n\n`+data.slice(1).map(row=>`${row[0]}\nFuture: ${row[1]} | CE: ${row[2]} | PE: ${row[3]}`).join('\n\n');try{await navigator.clipboard.writeText(text);copyText.textContent='Text copied';setTimeout(()=>{if(copyText.isConnected)copyText.textContent='Copy text';},1400);}catch{copyText.textContent='Copy unavailable';}};actions.append(copyImage,copyText);title.append(actions);
}
async function showOiTooltip(cell){const box=$('macdOiHoverSummary');if(!box)return;const symbol=cell.textContent.trim().toUpperCase();activeOiCell=cell;box.hidden=false;box.textContent='Loading recent daily data…';const rect=cell.getBoundingClientRect(),width=Math.min(440,window.innerWidth-20);box.style.width=`${width}px`;box.style.left=`${Math.max(10,Math.min(rect.left,window.innerWidth-width-10))}px`;box.style.top=`${Math.max(10,Math.min(rect.bottom+7,window.innerHeight-180))}px`;try{const snapshots=await loadOiSnapshots();if(activeOiCell===cell)paintOiTooltip(box,symbol,snapshots);}catch(error){if(activeOiCell===cell)box.textContent=`Could not load OI history: ${error.message}`;}}
function hideOiTooltip(){clearTimeout(oiHideTimer);oiHideTimer=setTimeout(()=>{activeOiCell=null;if($('macdOiHoverSummary'))$('macdOiHoverSummary').hidden=true;},120);}
function render(){
 if(!report)return;
 const groups={FULL:'Full alignment',NEAR:'Entry zone',PULLBACK:'Pullback / bounce'};
 const q=$('filter').value.trim().toUpperCase(), side=$('side').value;
 const rows=(report[side]||[]).filter(r=>(r.momentum||'strong')===$('momentum').value&&(r.short||'').toUpperCase().includes(q)&&(!$('minprice').valueAsNumber || (r.price ?? 0)>=$('minprice').valueAsNumber)&&($('group').value==='all'||r.category===$('group').value));
 rows.sort((a,b)=>$('sort').value==='name'?a.short.localeCompare(b.short):$('sort').value==='price'?(b.price||0)-(a.price||0):(b.count-a.count)||a.short.localeCompare(b.short));
 const headings=['Stock','Price ₹',...report.order,'Chain','Group','Waiting / state'];$('scannerColumns').replaceChildren(...headings.map(text=>{const th=document.createElement('th');th.textContent=text;return th;}));
 const fragment=document.createDocumentFragment();
 for(const r of rows){
  const tr=document.createElement('tr');
  const cell=(value,className='')=>{const td=document.createElement('td');td.textContent=value;td.className=className;tr.append(td);return td;};
  const symbolCell=cell(r.short,'macd-symbol oi-hover-trigger');symbolCell.title='Hover to compare the last 3 days of Open Interest';
  cell(r.price==null?'—':Number(r.price).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2}),'macd-price');
  for(const tf of report.order){
   const td=cell('','macd-timeframe');
   const chip=document.createElement('span');
   const st=r.states?.[tf], aligned=(r.aligned||[]).includes(tf),waiting=tf===r.waiting;
   chip.className='momentum-chip'+(aligned?(side==='buy'?' aligned-bull':' aligned-bear'):waiting?' waiting':'');
   const title=document.createElement('b'), detail=document.createElement('small');
   const trend=st?.trend || (aligned?(side==='buy'?'Strong Bull':'Strong Bear'):waiting?r.waiting_state:null);
   const building=tf==='M' && (r.momentum==='weak' || trend==='Recovering' || trend==='Weakening');
   const bullish=st?st.macd>=st.signal:building?(side==='buy'):trend==='Strong Bull';
   const strong=trend==='Strong Bull'||trend==='Strong Bear';
   title.textContent=building?`Building ${bullish?'↑':'↓'}`:strong?`M ${bullish?'↑':'↓'}`:'—';
   if(st)detail.textContent=st.macd>0?'Above 0':st.macd<0?'Below 0':'At 0';
   else detail.textContent=building?(bullish?'Below 0':'Above 0'):strong?(bullish?'Above 0':'Below 0'):waiting?(r.waiting_state||'Waiting'):'Not checked';
   if(building)chip.className='momentum-chip building';
   const crossover=st?(bullish?'PCO — positive crossover':'NCO — negative crossover'):strong||building?(bullish?'PCO — positive crossover':'NCO — negative crossover'):trend||'Not checked';
   chip.title=`${tf}: ${crossover} · ${detail.textContent}${building?' · Building momentum; Monthly exception':''}`;
   chip.setAttribute('aria-label',chip.title);
   chip.append(title,detail);td.append(chip);
  }
  cell(`${r.count}/${report.order.length}`,side==='buy'?'positive':'negative');
  cell(groups[r.category]||r.category);
  cell(r.waiting==='-'?'All aligned':`${r.waiting} · ${r.waiting_state||'—'}`);
  fragment.append(tr);
 }
 $('empty').textContent=$('momentum').value==='weak'&&!report.momentum_version?'Run a new scan to collect Building momentum results.':'No matches for these filters.';
 $('rows').replaceChildren(fragment);$('empty').hidden=rows.length>0;$('counts').textContent=`${rows.length} shown · ${report.buy.filter(r=>(r.momentum||'strong')===$('momentum').value).length} bullish · ${report.sell.filter(r=>(r.momentum||'strong')===$('momentum').value).length} bearish`;
}
async function scanStatus(){
 try{const response=await fetch('/api/macd/status');const s=await response.json();if(!response.ok)throw Error(s.error||'Scanner status unavailable');if(s.automation){if(!automationInitialized){$('hourlyScan').checked=s.automation.hourly;$('telegramAlerts').checked=s.automation.alerts;automationInitialized=true;}$('automationStatus').textContent=s.automation.error || (s.automation.telegram_ready?'Telegram configured':'Telegram credentials missing');}if(!priceInitialized){$('scanMinPrice').value=s.min_price ?? 1000;priceInitialized=true;}$('run').disabled=s.running||!s.enabled;$('run').textContent=s.running?'Scanning…':'Run scan';$('scanStatus').textContent=`${s.running?'RUNNING · ':''}${s.source==='bhavcopy'?'Bhavcopy F&O':'Watchlist'} · Price > ₹${s.min_price ?? 1000} · ${s.progress}${s.error?' · '+s.error:''}${s.finished_at?' · Finished '+new Date(s.finished_at).toLocaleString('en-IN',{timeZone:'Asia/Kolkata'}):''}`;}
 catch(e){$('scanStatus').textContent=e.message+' · Restart the updated dashboard server if this route is missing.';}
}
$('run').onclick=async()=>{
 if(!$('scanMinPrice').reportValidity() || !Number.isFinite($('scanMinPrice').valueAsNumber)){$('scanStatus').textContent='Enter a valid scan price (0 disables the cutoff).';return;}
 $('run').disabled=true;
 try{const response=await fetch('/api/macd/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source:$('universe').value,min_price:$('scanMinPrice').valueAsNumber})});const result=await response.json();if(!response.ok)throw Error(result.error||'Could not start scan');await scanStatus();}
 catch(e){$('scanStatus').textContent=e.message;$('run').disabled=false;}
};
async function load(){if(busy)return;busy=true;const source=$('universe').value;try{const response=await fetch('/api/macd?source='+encodeURIComponent(source));const data=await response.json();if(source!==$('universe').value)return;if(!response.ok)throw Error(data.error||'Report unavailable');report=data.report;$('error').hidden=true;$('meta').textContent=`Stock list: ${report.universe_label || 'Watchlist'}${report.bhavcopy_date?' ('+report.bhavcopy_date+')':''} · Scan price: ${report.scan_min_price == null ? 'not recorded' : report.scan_min_price === 0 ? 'no cutoff' : '> ₹'+report.scan_min_price} · Candles: FYERS · Report: ${report.stamp} · ${report.scanned} stocks scanned · ${report.order.join(' › ')} · minimum chain ${report.min} · Saved file, not a live scan` ;render();}catch(e){if(source===$('universe').value){$('error').hidden=false;$('error').textContent=e.message+(report?' · Displaying the last loaded report for this stock list.':'' );}}finally{busy=false;}}
$('rows').addEventListener('mouseover',event=>{const cell=event.target.closest('td.oi-hover-trigger');if(!cell||cell===activeOiCell)return;clearTimeout(oiHideTimer);showOiTooltip(cell);});
$('rows').addEventListener('mouseout',event=>{const cell=event.target.closest('td.oi-hover-trigger');if(cell&&!cell.contains(event.relatedTarget))hideOiTooltip();});
$('macdOiHoverSummary').addEventListener('mouseenter',()=>clearTimeout(oiHideTimer));$('macdOiHoverSummary').addEventListener('mouseleave',hideOiTooltip);window.addEventListener('scroll',()=>{if(activeOiCell)hideOiTooltip();},{passive:true});
for(const id of ['momentum','side','group','filter','minprice','sort'])$(id).addEventListener('input',render);
$('universe').addEventListener('change',()=>{report=null;$('rows').replaceChildren();$('counts').textContent='';$('meta').textContent='Loading selected stock list report…';$('empty').hidden=true;try{localStorage.setItem('macd-universe',$('universe').value);}catch{}load();});
$('reload').onclick=()=>{load();scanStatus();};
async function loadOiHistory(){try{const response=await fetch('/api/history?job=nse');const history=await response.json();if(!response.ok)throw Error(history.error||'History unavailable');oiHistory=history;oiCacheKey='';oiSnapshots=[];}catch{oiHistory=[];}}
load();scanStatus();loadOiHistory();setInterval(()=>{load();scanStatus();},5000);
