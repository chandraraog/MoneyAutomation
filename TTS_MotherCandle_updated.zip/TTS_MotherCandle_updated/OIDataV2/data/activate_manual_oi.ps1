$ErrorActionPreference = 'Stop'
$deadline = (Get-Date).AddHours(2)
while ((Get-Date) -lt $deadline) {
    $target = Get-CimInstance Win32_Process -Filter 'ProcessId = 28160'
    if (-not $target -or $target.CommandLine -notlike '*OIDataV2\server.py*') { exit }
    try { $macd = Invoke-RestMethod 'http://127.0.0.1:8765/api/macd/status' } catch { exit }
    if (-not $macd.running) {
        Stop-Process -Id 28160
        Start-Process -FilePath 'C:\Program Files\Python313\python.exe' -ArgumentList '-u','C:\dashboard\TTS_MotherCandle_updated\OIDataV2\server.py','--no-macd' -WorkingDirectory 'C:\dashboard\TTS_MotherCandle_updated\OIDataV2' -WindowStyle Hidden -RedirectStandardOutput 'C:\dashboard\TTS_MotherCandle_updated\OIDataV2\data\dashboard.stdout.log' -RedirectStandardError 'C:\dashboard\TTS_MotherCandle_updated\OIDataV2\data\dashboard.stderr.log'
        exit
    }
    Start-Sleep -Seconds 10
}
