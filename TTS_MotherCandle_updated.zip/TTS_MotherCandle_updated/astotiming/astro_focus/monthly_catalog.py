"""Optional, explicitly unverified calculated calendar from bundled research catalogs."""
from datetime import datetime, timedelta
from calendar import monthrange
from research.engine import events, event_key
from astro_calendar_v3 import HEAD

RULES = {
 'krishna_trayodashi':('Krishna Trayodashi','Must Watch','Bearish','P1'),
 'shukla_trayodashi':('Shukla Trayodashi','Must Watch','Bullish','P1'),
 'purnima':('Purnima','Must Watch','Reversal','P1'), 'amavasya':('Amavasya','Must Watch','Reversal','P1'),
 'moon_in_moola':('Moon in Moola','Nakshatra Transit','Bearish','P1'),
 'moon_in_pushya':('Moon in Pushya','Nakshatra Transit','Bearish / reversal','P1'),
 'moon_in_uttara_phalguni':('Moon in Uttara Phalguni','Nakshatra Transit','Bullish','P1'),
 'moon_in_jyeshtha':('Moon in Jyeshtha','Nakshatra Transit','Research','P2'),
 'moon_in_ashwini_pada_3':('Moon in Ashwini Pada 3','Nakshatra Transit','Bullish','P2'),
 'gandamool':('Gandamool','Gandamool','Research','P2'),
 'moon_mars':('Moon Mars','Conjunction','Bullish / reversal','P1'),
 'moon_jupiter':('Moon Jupiter','Conjunction','Bearish','P2'),
 'moon_saturn':('Moon Saturn','Conjunction','Bullish','P2'),
 'moon_venus':('Moon Venus','Conjunction','Bearish','P2'),
 'mars_jupiter':('Mars Jupiter','Conjunction','Directional watch','P1'),
 'mars_rahu':('Mars Rahu','Conjunction','Volatility','P1'),
 'mars_rahu_within_3':('Mars Rahu within 3','Massive Moves','Volatility','P1'),
 'mars_12th_from_saturn':('Mars 12th from Saturn','Massive Moves','Directional watch','P1'),
 'saturn_rashi_change':('Saturn Rashi Change','Massive Moves','Bearish','P1'),
 'jupiter_rashi_change':('Jupiter Rashi Change','Rashi Transit','Directional watch','P1'),
 'mercury_combustion':('Mercury Combustion','Combustion','Research','P2'),
 **{f'{p}_{s}':(f'{p.title()} {s}','Retrograde','Research','P2') for p in ('saturn','jupiter') for s in ('retrograde','direct')}
}
def calculated_month(year, month, imported):
    lo=datetime(year,month,1); hi=lo+timedelta(days=monthrange(year,month)[1]); result=[]
    for key,(name,category,bias,priority) in RULES.items():
        for r in events(key):
            a=datetime.fromisoformat(r['start_ist']); b=datetime.fromisoformat(r['end_ist'] or r['start_ist'])
            if not (a<hi and b>=lo): continue
            # Prefer published records for the same event in the same approximate window.
            if any(event_key(x['event'])==key and datetime.fromisoformat(x['start_ist'])<=b+timedelta(days=1) and datetime.fromisoformat(x['end_ist'] or x['start_ist'])>=a-timedelta(days=1) for x in imported): continue
            result.append(dict(zip(HEAD,[r['start_ist'],r['end_ist'],category,name,bias,priority,'All',r['source'],r['status'],'Calculated research catalog; not published source data; hypothesis only'])))
    return result
