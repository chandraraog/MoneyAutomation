from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path
from focus import ROOT, DATA, OUT, build, load, next_month
from timing_integration import fetch_day, line
from threading import Lock
import re
import swisseph as swe
app=FastAPI(title='Astro Focus V4.7.3')
lock=Lock()
app.mount('/static',StaticFiles(directory=ROOT/'static'),name='static')
def month_parts(month):
    if not re.fullmatch(r'\d{4}-\d{2}',month): raise HTTPException(400,'Use YYYY-MM')
    try: d=date.fromisoformat(month+'-01')
    except ValueError: raise HTTPException(400,'Invalid month')
    return d.year,d.month
@app.get('/')
def home(): return FileResponse(ROOT/'static/index.html')
@app.get('/api/months')
def months():
    today=datetime.now(ZoneInfo('Asia/Kolkata')).date(); y,m=next_month(today.year,today.month)
    return {'today':today.isoformat(),'months':[f'{year}-{month:02}' for year in range(2000,2051) for month in range(1,13)]}
@app.get('/api/calendar/{month}')
def calendar(month:str):
    y,m=month_parts(month)
    with lock:
        if not (OUT/f'positional_{month}.csv').exists(): build(y,m)
        return {'focus':load(OUT/f'focus_{month}.csv'),'positional':load(OUT/f'positional_{month}.csv'),'events':load(OUT/f'events_{month}.csv'),'rules':load(ROOT/'rules.csv'),'coverage':load(ROOT/'coverage.csv'),'research_available':{r['event']:availability(r['event']) for r in load(OUT/f'events_{month}.csv')}}
@app.post('/api/calendar/{month}')
def generate(month:str, include_calculated:bool=False):
    y,m=month_parts(month)
    with lock: build(y,m,include_calculated=include_calculated)
    return calendar(month)
@app.get('/api/excel/{month}')
def excel(month:str):
    calendar(month)
    return FileResponse(OUT/f'Astro_Focus_{month}.xlsx',filename=f'Astro_Focus_{month}.xlsx')
@app.get('/api/timings/{day}')
def timings(day:date):
    try: rows=fetch_day(day)
    except Exception as e: raise HTTPException(502,f'Prokerala fetch failed: {e}')
    # D1/Rashi whole-sign houses for the NSE reference location. The provider's
    # event timezone is not verified, so its displayed clock is treated as IST.
    swe.set_sid_mode(swe.SIDM_LAHIRI)
    planets={'sun':swe.SUN,'moon':swe.MOON,'mars':swe.MARS,'mercury':swe.MERCURY,
             'jupiter':swe.JUPITER,'venus':swe.VENUS,'saturn':swe.SATURN,
             'node':swe.MEAN_NODE,'rahu':swe.MEAN_NODE}
    rashis=('Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio',
            'Sagittarius','Capricorn','Aquarius','Pisces')
    rashi_lords=('Mars','Venus','Mercury','Moon','Sun','Mercury','Venus','Mars',
                 'Jupiter','Saturn','Saturn','Jupiter')
    for row in rows:
        try:
            event_date=date.fromisoformat(row['date'])
            clock=datetime.strptime(row['time'].strip().upper(),'%H:%M').time()
            local=datetime.combine(event_date,clock).replace(tzinfo=ZoneInfo('Asia/Kolkata'))
            utc=local.astimezone(ZoneInfo('UTC'))
            jd=swe.julday(utc.year,utc.month,utc.day,utc.hour+utc.minute/60+utc.second/3600)
            _, angles=swe.houses_ex(jd,19.0760,72.8777,b'W',swe.FLG_SIDEREAL)
            asc_sign=int(angles[0]//30)
            def position(name):
                key=name.strip().lower()
                if key=='ketu': longitude=(swe.calc_ut(jd,swe.MEAN_NODE,swe.FLG_MOSEPH|swe.FLG_SIDEREAL)[0][0]+180)%360
                elif key in planets: longitude=swe.calc_ut(jd,planets[key],swe.FLG_MOSEPH|swe.FLG_SIDEREAL)[0][0]
                else: return ('Not in 9-planet chart','—','—','—')
                sign=int(longitude//30)
                return (f'House {(sign-asc_sign)%12+1}',sign+1,rashis[sign],rashi_lords[sign])
            for prefix, name in (('planet1',row['planet1']),('planet2',row['planet2'])):
                row[f'{prefix}_house'],row[f'{prefix}_rashi_number'],row[f'{prefix}_rashi'],row[f'{prefix}_rashi_lord']=position(name)
        except (KeyError,ValueError,TypeError):
            for prefix in ('planet1','planet2'):
                row[f'{prefix}_house']=row[f'{prefix}_rashi_number']=row[f'{prefix}_rashi']=row[f'{prefix}_rashi_lord']='Unavailable'
    return {'rows':rows,'text':'\n'.join(map(line,rows)),'timezone':'Mumbai · D1 whole-sign · Lahiri/Chitra Paksha · listed event time assumed IST'}

@app.get('/api/lookup')
def lookup_data():
    try:
        from lookup import load_tables, planet
        sectors,d9,rashi,keys,aliases=load_tables()
        clean=lambda rows:[{str(k):v for k,v in row.items() if k is not None} for row in rows]
        planets=sorted({planet(row.get(f'Planet {i}')) for row in sectors for i in (1,2,3)}-{''})
        return {'sectors':clean(sectors),'d9':clean(d9),'rashi':clean(rashi),'d9_keys':keys,
                'rashi_aliases':aliases,'sector_planets':planets}
    except Exception as exc:
        raise HTTPException(500,f'Cannot read Combined_Lookup.xlsx: {exc}')

@app.get('/api/lookup/workbook')
def lookup_workbook():
    from lookup import WORKBOOK
    if not WORKBOOK.exists(): raise HTTPException(404,'Combined_Lookup.xlsx not found.')
    return FileResponse(WORKBOOK,filename=WORKBOOK.name)

from research.engine import analyze, catalog, refresh, MARKETS, availability, default_count, event_key
@app.get('/api/research/catalog')
def research_catalog(): return {'events':catalog(),'markets':list(MARKETS),'defaults':{n:default_count(n) for n in catalog()},'aliases':{r['event']:event_key(r['event']) for month in ('2026-11','2026-12') for r in load(OUT/f'events_{month}.csv')},'available':{event_key(n):availability(n) for n in catalog()}}
@app.get('/api/research')
def research(event:str, market:str='NIFTY 50', count:int=10, mode:str='post'):
    try: return analyze(event,market,count,mode)
    except (ValueError, KeyError) as e: raise HTTPException(400,str(e))
@app.post('/api/research/fetch')
def research_fetch(event:str,market:str='NIFTY 50',count:int=10):
    try:
        if count not in (5,10,20,30,50,100): raise ValueError('Invalid count')
        with lock: return {'downloaded':refresh(event,market,count)}
    except Exception as e: raise HTTPException(502,str(e))
